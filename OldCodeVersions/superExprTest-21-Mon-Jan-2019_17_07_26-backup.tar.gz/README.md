#TODO:
- Implement the existential operator
- implement a more "resilient" predicate/subject naming scheme ideally they should be their own class in which they can be single upper or lower case letters
	or subscripted upper or lower case letters. this naming will probably require paren mode output and modification of at least varexps if not mroe
- debug existential expressions more
- write better/more testing and testing tools
- a heredoc wrapper will be created for the calculator translator.
#NOTES:
- Relations can be printed in parenthesized or juxtaposed mode (though this must be selected by commenting or uncommenting the correct code at compile time...)
- boolexps all share three sets representing the universe of subjects predicates and tuples containing the truth falsity and unknowness of each predicate
- quantifiers and Evaluate() are with respect to the "known universe"
