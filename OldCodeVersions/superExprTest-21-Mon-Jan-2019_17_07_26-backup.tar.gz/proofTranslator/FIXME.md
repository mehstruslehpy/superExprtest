Work the infinite loop problem
Gensler.8.3a.8.sh
Gensler.8.5a.2.sh
Gensler.8.5a.4.sh
Gensler.8.5a.9.sh
Gensler.8.5a.12.sh
Gensler.8.5a.14.sh
NOTE: if you do, you can see the formulas holding up the inference
./Gensler.8.5a.14.sh | grep "infer because"
