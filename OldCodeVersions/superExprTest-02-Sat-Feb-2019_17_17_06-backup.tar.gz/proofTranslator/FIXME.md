NOTE: if you do, you can see the formulas holding up the inference
./Gensler.8.5a.14.sh | grep "infer because"
./Gensler.8.3a.3.sh
./Gensler.8.5a.2.sh
./Gensler.8.5a.4.sh
